export class Card{
    cardId:number;
    cardName:string;
    cardNumber:string;
    cardExpiry:Date;
    cvv:number;
    bankName:string;
    constructor(cardId:number, cardName:string,  cardNumber:string, cardExpiry:Date, cvv:number, bankName:string){
        this.cardId = cardId;
this.cardName = cardName;
this.cardNumber = cardNumber;
this.cardExpiry = cardExpiry;
this.cvv = cvv;
        this.bankName =bankName;
}
}