
import { Address } from "./address";

export class Customer
{
    id:number;
    customerName:string;
    dob:Date;
    phoneNumber:number;
    emailId:string;
    address:String;
    constructor(id:number,customerName:string,dob:Date,phoneNumber:number, emailId:string, address:String)
    {
        this.id=id;
        this.customerName=customerName;
        this.dob=dob;
        this.phoneNumber=phoneNumber;
        this.emailId=emailId;
        this.address=address;
    }
}