export class Address{
    doorNum:number;
    constructor(doorNum:number)
    {
        this.doorNum=doorNum;
    }

}