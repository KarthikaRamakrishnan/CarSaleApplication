import { Card } from "./card";

export class Payment{
    paymentId:number;
     type:string;
     status:string;
     bankName:string;
     card:Card;
     constructor(paymentId:number, type:string, status:string,bankName:string, card:Card){
        this.paymentId = paymentId;
        this.type = type;
        this.status = status;  
        this.card = card;
        this.bankName=bankName;
    }
 }