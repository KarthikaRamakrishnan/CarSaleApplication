import { Customer } from "./customer";

export class Car {
    carId: number;
    variant: string;
    brand: string;
    model: string;
    registrationState : string;
    registrationYear : Date;
    customer:Customer;
 
    constructor(carId : number, variant : string,brand : string, model : string,registrationState : string,registrationYear : Date, customer:Customer) {
        this.carId=carId;
        this.brand=brand;
        this.model=model;
        this.variant=variant;
        this. registrationYear= registrationYear;
        this.registrationState=registrationState;
        this.customer=customer;
    }
    
}