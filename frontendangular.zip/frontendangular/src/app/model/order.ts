import { Customer } from "./customer";

export class Order{
    id:number;
    amount :number;
    billingDate:Date;
    paymentMethod:string;
    customer:Customer;
  


 
    constructor(id:number,
        amount :number,billingDate:Date, paymentMethod:string,customer:Customer){
           this.id=id;
            this.amount=amount;
            this.billingDate=billingDate;
            this.paymentMethod=paymentMethod;
            this.customer=customer;
            
        }
}