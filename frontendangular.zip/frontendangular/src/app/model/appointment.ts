


export class Appointment{
 
    id:number;
    location:string;
    inspectType:string;
    preferredDate: Date;
 
    constructor(id:number,location:string,inspectType:string,preferredDate: Date)
    {
        this.id=id;
        this.location=location;
        this.inspectType=inspectType;
        this.preferredDate=preferredDate;

    }
    
}