import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { OrderService } from 'src/app/_services/order.service';

@Component({
  selector: 'app-add-order',
  templateUrl: './add-order.component.html',
  styleUrls: ['./add-order.component.css']
})
export class AddOrderComponent implements OnInit {
  addForm: FormGroup;
  submitted: boolean = false;

  constructor(private formBuilder: FormBuilder, private router: Router, 
    private orderService: OrderService) { 
      this.addForm = this.formBuilder.group({
        id:['',Validators.required],
        amount: ['', Validators.required],
        billingDate:[''],
        paymentMethod: ['']
      });
     
     
    }
   

  ngOnInit() {
    
  }
  onSubmit() {
    this.submitted = true;
    if(this.addForm.invalid){
      alert('order is invalid')
      return;
    }
    console.log(this.addForm.value);
    this.orderService.createOrder(this.addForm.value)
      .subscribe( data => {
        this.router.navigate(['list-order']);
       
      });
  }
}
  
