import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddOrderComponent } from './add-order/add-order.component';
import { OrderService } from 'src/app/_services/order.service';
import { ReactiveFormsModule } from '@angular/forms';
import { ListOrderComponent } from './list-order/list-order.component';
import { EditOrderComponent } from './edit-order/edit-order.component';





@NgModule({
  declarations: [AddOrderComponent, ListOrderComponent, EditOrderComponent],
  imports: [
    CommonModule,ReactiveFormsModule
  ],
  exports:[AddOrderComponent,ListOrderComponent],
  providers:[OrderService]
})
export class OrderModule { }
