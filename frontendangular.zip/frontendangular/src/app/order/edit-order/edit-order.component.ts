import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { OrderService } from 'src/app/_services/order.service';
import {first} from "rxjs/operators";

@Component({
  selector: 'app-edit-order',
  templateUrl: './edit-order.component.html',
  styleUrls: ['./edit-order.component.css']
})
export class EditOrderComponent implements OnInit {
  
  editForm: FormGroup;
  submitted: boolean = false;

  constructor(private formBuilder: FormBuilder, private router: Router, 
    private orderService: OrderService) {
      this.editForm = this.formBuilder.group({
        id:['',Validators.required],
        amount: ['', Validators.required],
        billingDate:[''],
        paymentMethod: ['']
      });
    }
     

  ngOnInit(): void {
    let orderid=localStorage.getItem("editOrderId");
    if(!orderid)
    {
      alert("Invalid action.")
      this.router.navigate(['list-order']);
      return;
    }
    this.orderService.getOrderById(+orderid).subscribe(data=>{this.editForm.setValue(data);});
    
  }
  onSubmit() {
    if(this.editForm.invalid)
    {
      alert('Invalid editform');
      return;

    }
    this.orderService.updateOrder(this.editForm.value)
    .pipe(first())
    . subscribe(
      data=>{
        this.router.navigate(['list-order']);},
      error=>{
        alert('error: '+error.url);
      });
    }

}
  


