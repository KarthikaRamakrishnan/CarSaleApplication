import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Order } from 'src/app/model/order';
import { OrderService }from 'src/app/_services/order.service';

@Component({
  selector: 'app-list-order',
  templateUrl: './list-order.component.html',
  styleUrls: ['./list-order.component.css']
})
export class ListOrderComponent implements OnInit {
  orders!:Order[];

  constructor(private router:Router, private orderService:OrderService) { }

  ngOnInit():void  {
    this.orderService.getOrders().subscribe(data=> {
      this.orders = data;
  });

}
deleteOrder(Order: Order): void {
  let result = confirm('Do you want to delete the order?')
  if(result)
  {
    this.orderService.deleteOrder(Order.id)
      .subscribe( data => {
        this.orders = this.orders.filter(u => u !== Order);
      });
    }
};
editOrder(order: Order){
  localStorage.removeItem("editOrderId");
  localStorage.setItem("editOrderId", order.id.toString());
  this.router.navigate(['edit-order']);
  };
  }
