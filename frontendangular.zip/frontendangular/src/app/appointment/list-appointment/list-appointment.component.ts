import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {  Appointment } from 'src/app/model/appointment';
import { AppointmentService } from 'src/app/_services/appointment.service';

@Component({
  selector: 'app-list-appointment',
  templateUrl: './list-appointment.component.html',
  styleUrls: ['./list-appointment.component.css']
})
export class ListAppointmentComponent implements OnInit {
  appointments!:Appointment[];

  constructor(private router:Router,private appointmentService:AppointmentService) { }

  ngOnInit() {
    this.appointmentService.getAppointment().subscribe(data=> {
      this.appointments = data;
    });
  }
  
    }

