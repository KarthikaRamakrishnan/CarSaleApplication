import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddAppointmentComponent } from './add-appointment/add-appointment.component';
import { ListAppointmentComponent } from './list-appointment/list-appointment.component';
import { ReactiveFormsModule } from '@angular/forms';
import { AppointmentService } from 'src/app/_services/appointment.service';



@NgModule({
  declarations: [AddAppointmentComponent, ListAppointmentComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule
  ],
  exports:[AddAppointmentComponent,ListAppointmentComponent],
  providers:[AppointmentService]
})
export class AppointmentModule { }
