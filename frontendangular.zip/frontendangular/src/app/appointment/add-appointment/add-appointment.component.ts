import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import {AppointmentService} from 'src/app/_services/appointment.service';

@Component({
  selector: 'app-add-appointment',
  templateUrl: './add-appointment.component.html',
  styleUrls: ['./add-appointment.component.css']
})
export class AddAppointmentComponent implements OnInit {

  addForm: FormGroup;
  submitted: boolean = false;

  constructor(private formBuilder: FormBuilder, private router: Router, 
    private appointmentService: AppointmentService) { 
      this.addForm = this.formBuilder.group({
        id:[''],
        location: ['', Validators.required],
      inspectType:['', Validators.required],
        preferredDate: ['', Validators.required],
      
      });
    }

  ngOnInit() {
    
  }
  onSubmit() {
    this.submitted=true;
    if(this.addForm.invalid)
    {
      alert('Invalid appointment');
      return;

    }
    this.appointmentService.createAppointment(this.addForm.value)
      .subscribe(data => {
        this.router.navigate(['list-appointment']);
      });
    }
}

 