import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddPaymentComponent } from './add-payment/add-payment.component';
import { PaymentService } from 'src/app/_services/payment.service';
import { ReactiveFormsModule } from '@angular/forms';
import { ListPaymentComponent } from './list-payment/list-payment.component';
import { EditPaymentComponent } from './edit-payment/edit-payment.component';



@NgModule({
  declarations: [AddPaymentComponent, ListPaymentComponent, EditPaymentComponent],
  imports: [
    CommonModule, ReactiveFormsModule
  ],
  exports:[AddPaymentComponent,ListPaymentComponent,EditPaymentComponent],
  providers:[PaymentService]
})
export class PaymentModule { }
