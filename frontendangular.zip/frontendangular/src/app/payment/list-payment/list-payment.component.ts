import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Payment } from 'src/app/model/payment';
import { PaymentService } from 'src/app/_services/payment.service';

@Component({
  selector: 'app-list-payment',
  templateUrl: './list-payment.component.html',
  styleUrls: ['./list-payment.component.css']
})
export class ListPaymentComponent implements OnInit {

  payments!: Payment[];

  // first one to execute and after that ngOnInit
  constructor(private router: Router, private paymentService: PaymentService) { }

  // Initialize with default list of payments
  ngOnInit(): void {
     
      this.paymentService.getAllPayments()
        .subscribe(data => {
          alert(JSON.stringify(data));
          this.payments = data;
        });
      alert('after subsribe.......');
    }
    


  // Delete Payment
  deletePayment(payment: Payment): void {
    let result = confirm('Do you want to delete the payment?')
    if (result) {
      alert('before delete');
      this.paymentService.deletePayment(payment.paymentId)
        .subscribe(data => {
          alert('after delete');
          this.payments = this.payments.filter(p => p !== payment);
        });

    }
  };

  // Modify Payment
  updatePayment(payment: Payment): void {
    this.paymentService.updatePayment(payment);
    this.router.navigate(['edit-payment']);
  };

  // Add New Payment
  addPayment(): void {
    this.router.navigate(['add-payment']);
  };
}
