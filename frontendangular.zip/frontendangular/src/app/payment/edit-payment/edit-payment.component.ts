import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Payment } from 'src/app/model/payment';
import { PaymentService }from 'src/app/_services/payment.service';
import {first} from 'rxjs/operators';

@Component({
  selector: 'app-edit-payment',
  templateUrl: './edit-payment.component.html',
  styleUrls: ['./edit-payment.component.css']
})
export class EditPaymentComponent implements OnInit {

  payment!: Payment;
  editForm!: FormGroup;
  submitted: boolean = false;
  constructor(private formBuilder: FormBuilder,private router: Router, 
    private paymentService: PaymentService) {
      this.editForm = this.formBuilder.group({
        paymentId: [],
        type: ['', Validators.required],
        status: ['', Validators.required],
        cardName: ['', Validators.required],
        cardNumber: ['', Validators.required],
        cardExpiry: ['', Validators.required],
        cvv: ['', Validators.required],
        bankName: ['', Validators.required]
      });
     }

  ngOnInit() {
    let paymentId = localStorage.getItem("editpaymentId");
    if(!paymentId) {
     alert("Invalid action.")
     this.router.navigate(['list-payment']);
     return;
    }
    
    this.paymentService.getPaymentBypaymentId(+paymentId)
    .subscribe( data => {
      this.editForm.setValue(data);
    });
  }

  onSubmit() {
      /* this.submitted = true;
      if (this.editForm.invalid) {
        alert('invalid editform');
        return;
      }*/
      this.paymentService.updatePayment(this.editForm.value)
      .pipe(first())
        .subscribe(data => {
          this.router.navigate(['list-payment']);
          alert("Payment is updated");
        },
        error => {
          alert('error: '+error.url);
         });
    
    }
    
}
