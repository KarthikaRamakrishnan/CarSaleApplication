import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { PaymentService } from 'src/app/_services/payment.service';

@Component({
  selector: 'app-add-payment',
  templateUrl: './add-payment.component.html',
  styleUrls: ['./add-payment.component.css']
})
export class AddPaymentComponent implements OnInit {

  addForm: FormGroup;

  submitted: boolean = false;

  constructor(private formBuilder: FormBuilder, private router: Router,
    private paymentService: PaymentService) {
    this.addForm = this.formBuilder.group({
      paymentId: ['1'],
      type: ['Card', Validators.required],
      // status: ['Success'],
      card:this.formBuilder.group({
      cardName: ['Suji', Validators.required],
      cardNumber: ['4563 7896 7896 4569', Validators.required],
      cardExpiry: ['', Validators.required],
      cvv: ['456', Validators.required],
     
    }),
    bankName: ['HDFC', Validators.required]
    });
  }

  ngOnInit(){

  }

  onSubmit() {
    this.submitted = true;
    if (this.addForm.invalid) {
      alert('Invalid data');
      return;
    }
    alert('PAYMENT SUCCESSFULL');
   
    this.paymentService.addPayment(this.addForm.value)
      .subscribe(data => {
        alert("Payment is added");
        this.router.navigate(['list-payment']);
        
      });
  }

}
