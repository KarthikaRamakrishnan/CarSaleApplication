import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from 'src/app/model/user';
import { UserService } from 'src/app/_services/user.service';
import {first} from "rxjs/operators";

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {
  user!: User;
  editForm: FormGroup;
  submitted: boolean = false;
  
  constructor(private formBuilder: FormBuilder,private router: Router, 
    private userService: UserService) {
      this.editForm = this.formBuilder.group({
        id:[''],
        firstName: ['', Validators.required],
        lastName:['', Validators.required],
        login:['', Validators.required],
        dob:['', Validators.required],
        mail:['', Validators.required],
        mobile:['', Validators.required],
        image:['']
          
      });
     }
  
  ngOnInit() {
    let userId = localStorage.getItem("editUserId");
    if(!userId) {
      alert("Invalid action.")
      this.router.navigate(['list-user']);
      return;
    }
    
    this.userService.getUserById(+userId)
      .subscribe( data => {
        this.editForm.setValue(data);
      });
    }
    

  onSubmit() {
    if(this.editForm.invalid){
      alert('invalid editform');
      return;
    }
    this.userService.updateUser(this.editForm.value)
      .pipe(first())
      .subscribe(
        data => {
          this.router.navigate(['list-user']);
        },
        error => {
          alert('error: '+error.url);
        });
  }

   // logOff user
   logOutUser():void{
    if(localStorage.getItem("username")!=null){
      localStorage.removeItem("username");
      this.router.navigate(['/login']);
    }
}

}
