import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/app/model/user';
import { UserService } from 'src/app/_services/user.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  users!: User[];

  constructor(private router: Router, private userService: UserService) { }

  ngOnInit() {
    if(localStorage.getItem("username")!=null){
     
    this.userService.getUsers().subscribe(data=> {
        this.users = data;
      });
    }
    else
    this.router.navigate(['/login']);
    
  }

  // logOff user
  logOutUser():void{
    if(localStorage.getItem("username")!=null){
      localStorage.removeItem("username");
      this.router.navigate(['/login']);
    }
}

// Add New User
createUser(): void {
this.router.navigate(['add-user']);
};

// View User List
viewUser():void{
  this.router.navigate(['list-user']);
};
}
