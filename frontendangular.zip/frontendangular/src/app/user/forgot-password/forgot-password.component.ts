import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from 'src/app/_services/user.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {

  forgotForm : FormGroup;
  UserService: any;
  password!: string;

  constructor(private formBuilder: FormBuilder, private router: Router,private service:UserService) {
    this.forgotForm = new FormGroup({
      email: new FormControl(),
      login: new FormControl()
    });
  }
 
  
  ngOnInit() {
  }
  
  errorMessage!:string;
  message!:string;

  onSubmit() {
    this.UserService.forgotPassword(this.forgotForm).subscribe(
      (      password: string)=>{
        this.password=password;
        alert(password);
        this.router.navigate(['/login']);
      },
      (  errorMessage: string)=>{
        this.errorMessage=errorMessage;
        alert("Please enter valid credentials!!");
      })
  }
}   
 

