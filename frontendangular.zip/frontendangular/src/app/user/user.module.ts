import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddUserComponent } from './add-user/add-user.component';
import { EditUserComponent } from './edit-user/edit-user.component';
import { ListUserComponent } from './list-user/list-user.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { UserService } from '../_services/user.service';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { ViewUserComponent } from './view-user/view-user.component';
import { LoginComponent } from './login/login.component';



@NgModule({
  declarations: [AddUserComponent, EditUserComponent, 
                ListUserComponent, ForgotPasswordComponent, ViewUserComponent,LoginComponent],
  imports: [
    CommonModule, 
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule
  ],
  providers: [UserService],
  exports:[AddUserComponent,ListUserComponent,ForgotPasswordComponent,EditUserComponent,ViewUserComponent]
})
export class UserModule { }
