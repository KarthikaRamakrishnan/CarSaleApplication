
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { User } from 'src/app/model/user';
import { UserService } from 'src/app/_services/user.service';

@Component({
  selector: 'app-view-user',
  templateUrl: './view-user.component.html',
  styleUrls: ['./view-user.component.css']
})
export class ViewUserComponent implements OnInit {

  users! : User;
  isLoadingResults=true;

  constructor(private service:UserService,private route:ActivatedRoute) { }

  ngOnInit(): void {
    this.getUserById(this.route.snapshot.params['id']);
  }

  getUserById(user:User){
    this.service.getUserById(user.id).subscribe((data: any) =>{
      this.users = data;
      console.log(this.users);
      this.isLoadingResults=false;
    })

  }

}
