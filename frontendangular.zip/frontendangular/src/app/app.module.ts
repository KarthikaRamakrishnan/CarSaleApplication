import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CustomerModule } from './customer/customer.module';
import { CarModule } from './car/car.module';
import { PaymentModule } from './payment/payment.module';

import { AppointmentModule } from './appointment/appointment.module';
import { OrderModule } from './order/order.module';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';
import{HttpClientModule} from'@angular/common/http';
import { HomeComponent } from './home/home.component';
import { GalleryComponent } from './gallery/gallery.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { UserModule } from './user/user.module';



@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    GalleryComponent,
    AboutUsComponent,
    ContactUsComponent
  
   
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CustomerModule,
    CarModule,
    UserModule,
    PaymentModule,
    AppointmentModule,
    OrderModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
