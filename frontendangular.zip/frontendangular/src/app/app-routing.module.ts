import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutUsComponent } from './about-us/about-us.component';
import { AddAppointmentComponent } from './appointment/add-appointment/add-appointment.component';
import { AddCarComponent } from './car/add-car/add-car.component';
import { EditCarComponent } from './car/edit-car/edit-car.component';
import { ListCarComponent } from './car/list-car/list-car.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { AddCustomerComponent } from './customer/add-customer/add-customer.component';
import { EditCustomerComponent } from './customer/edit-customer/edit-customer.component';
import { ListCustomerComponent } from './customer/list-customer/list-customer.component';
import { GalleryComponent } from './gallery/gallery.component';
import { HomeComponent } from './home/home.component';
import { AddOrderComponent } from './order/add-order/add-order.component';
import { EditOrderComponent } from './order/edit-order/edit-order.component';
import { ListOrderComponent } from './order/list-order/list-order.component';
import { AddPaymentComponent } from './payment/add-payment/add-payment.component';
import { EditPaymentComponent } from './payment/edit-payment/edit-payment.component';
import { ListPaymentComponent } from './payment/list-payment/list-payment.component';
import { AddUserComponent } from './user/add-user/add-user.component';
import { EditUserComponent } from './user/edit-user/edit-user.component';
import { ForgotPasswordComponent } from './user/forgot-password/forgot-password.component';
import { ListUserComponent } from './user/list-user/list-user.component';
import { LoginComponent } from './user/login/login.component';
import { AdminComponent } from './user/Profile/admin/admin.component';
import { ViewUserComponent } from './user/view-user/view-user.component';

const routes: Routes = [{path:'add-car',component:AddCarComponent},
                        {path:'list-car',component:ListCarComponent},
  {path:'edit-car',component:EditCarComponent},
  {path:'home',component:HomeComponent},
  {​​​​​​​​path:'add-payment',component:AddPaymentComponent}​​​​​​​​,
  {​​​​​​​​path:'list-payment',component:ListPaymentComponent}​​​​​​​​,
  {​​​​​​​​path:'edit-payment',component:EditPaymentComponent}​​​​​​​​,
  {​​​​​​​​path:'gallery',component:GalleryComponent}​​​​​​​​,
  { path: 'home', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'forgot-password', component: ForgotPasswordComponent },
  { path: 'admin', component: AdminComponent },
  { path: 'add-user', component: AddUserComponent },
  { path: 'edit-user', component: EditUserComponent },
  { path: 'list-user', component: ListUserComponent },
  { path: 'view-user', component: ViewUserComponent },{path:'add-order',component:AddOrderComponent},
  {path:'edit-order',component:EditOrderComponent},
  {path:'list-order',component:ListOrderComponent},
  {path:'add-customer',component:AddCustomerComponent},
  {path:'edit-customer',component:EditCustomerComponent},
  {path:'list-customer',component:ListCustomerComponent},
  {path:'add-appointment',component:AddAppointmentComponent},
  {path:'about-us',component:AboutUsComponent},
  {path:'contact-us',component:ContactUsComponent}
                      ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
