import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Customer } from '../model/customer';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  constructor(private http: HttpClient) { }
  baseUrl: string = 'http://localhost:9090/api/customers';
  createCustomer(customer: Customer):Observable<string>{
    alert('Data Test');
    return this.http.post(this.baseUrl+'/addCustomer'+'/', customer,{ responseType: 'text' });
  }
  getCustomers(){
    return this.http.get<Customer[]>(this.baseUrl+'/getAllCustomers');
  }
   // Get User By Id
   getCustomerrById(id: number){
    return this.http.get<Customer>(this.baseUrl+'/getcustomertById/'+id);
  }
  //modify customer details
 updateCustomer(customer: Customer) :Observable<string>{
    return this.http.put(this.baseUrl +'/updateCustomer/'+customer.id, customer,{ responseType: 'text' });
  }
// Delete User
  deleteCustomer(id: number):Observable<string>{
    return this.http.delete(this.baseUrl + '/deleteCustomer/' + id,{ responseType: 'text' });
  }

}
