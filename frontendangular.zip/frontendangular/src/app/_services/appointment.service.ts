import { Injectable } from '@angular/core';
import {Appointment} from 'src/app/model/appointment';
import {HttpClient} from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class AppointmentService {
  
  
  constructor(private http: HttpClient) { }
  baseUrl: string = 'http://localhost:3000/appointment';
  createAppointment(appointment: Appointment) {
    alert('Data Test');
    return this.http.post(this.baseUrl+'/', appointment);
  }

   getAppointment(){
    return this.http.get<Appointment[]>(this.baseUrl+'/');
  }

}

