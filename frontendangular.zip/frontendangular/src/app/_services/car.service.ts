import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Car } from '../model/car';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class CarService {
  constructor(private http: HttpClient) { }
  baseUrl: string = 'http://localhost:9090/cars';
  createCar(car: Car):Observable<string> {
    return this.http.post<string>(this.baseUrl+'/addCar'+ car,{ responseType: 'text' });
  }
 
  
 
  getCars() {
    return this.http.get<Car[]>(this.baseUrl+'/getAllCars');
  }
 
  getCarByCarId(carId: number){
    return this.http.get<Car>(this.baseUrl+'/getCarByCarId/'+carId);
  }
  
  updateCar(car: Car):Observable<string> {
    return this.http.put(this.baseUrl+'/updateCar/'+car.carId, car,{ responseType: 'text' });
  }
 
  deleteCar(carId: number):Observable<string> {
    return this.http.delete(this.baseUrl + '/deleteCar/'+carId,{ responseType: 'text' });
  }
}



