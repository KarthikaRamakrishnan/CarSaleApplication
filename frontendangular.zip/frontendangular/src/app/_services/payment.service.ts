import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Payment } from '../model/payment';

@Injectable({
  providedIn: 'root'
})
export class PaymentService {

  constructor(private http:HttpClient) { }

  baseUrl:string = 'http://localhost:9090/payments';
 
  // Add Payment
  addPayment(payment : Payment):Observable<string> {
    return this.http.post(this.baseUrl+'/addPayment'+'/', payment,{ responseType: 'text' });
  }
  
  //Update Payment
  updatePayment(payment : Payment) :Observable<string>{
    return this.http.put(this.baseUrl+'/updatePayment/'+payment.paymentId, payment,{ responseType: 'text' });
  }
  // Delete Payment
  deletePayment(paymentId: number):Observable<string> {
    return this.http.delete(this.baseUrl +'/deletePayment/'+ paymentId,{ responseType: 'text' });
  }

  // Get All Payments
  getAllPayments(){
    return this.http.get<Payment[]>(this.baseUrl+'/getAllPayments');
  }
  
  // Get Payment By Id
  getPaymentBypaymentId(paymentId: number){
    return this.http.get<Payment>(this.baseUrl+'/getPaymentBypaymentId/'+paymentId);
  }
}
