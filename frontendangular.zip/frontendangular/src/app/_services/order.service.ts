import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Order } from '../model/order';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  constructor(private http:HttpClient) { }

  baseUrl:string ='http://localhost:9090/api/orders';

  
  // Create order
  createOrder(order: Order): Observable<string> {
    alert('data-test')
    return this.http.post(this.baseUrl+'/addOrder', order,{ responseType: 'text' });
  }
  getOrders(){
    return this.http.get<Order[]>(this.baseUrl+'/getAllOrders');
  }
   // Get Order By Id
   getOrderById(id: number){
    return this.http.get<Order>(this.baseUrl+'/getOrderDetails/'+id);
  }
  //modify order details
 updateOrder(order: Order):Observable<string> {
    return this.http.put(this.baseUrl +'/updateOrder/'+order.id,order,{ responseType: 'text' });
  }
// Delete Order
  deleteOrder(id: number):Observable<string> {
    return this.http.delete(this.baseUrl + '/deleteOrder/' + id,{ responseType: 'text' });
  }

}


