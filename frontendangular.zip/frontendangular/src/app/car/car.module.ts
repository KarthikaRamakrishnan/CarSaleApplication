import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddCarComponent } from './add-car/add-car.component';
import { CarService } from 'src/app/_services/car.service';
import { ReactiveFormsModule } from '@angular/forms';
import { EditCarComponent } from './edit-car/edit-car.component';
import { ListCarComponent } from './list-car/list-car.component';




@NgModule({
  declarations: [AddCarComponent, ListCarComponent,EditCarComponent],
  imports: [
    CommonModule,ReactiveFormsModule
  ],
  exports : [AddCarComponent,ListCarComponent,EditCarComponent],
  providers:[CarService]
})
export class CarModule { }
