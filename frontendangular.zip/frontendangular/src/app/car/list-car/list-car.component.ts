import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { Car } from 'src/app/model/car';
import { CarService } from 'src/app/_services/car.service';
@Component({
  selector: 'app-list-car',
  templateUrl: './list-car.component.html',
  styleUrls: ['./list-car.component.css']
})
export class ListCarComponent implements OnInit {

  cars!: Car[];

  // first one to execute and after that ngOnInit
  constructor(private router: Router, private carService: CarService) { }
  ngOnInit() : void {
     
    this.carService.getCars().subscribe(data=> {
        this.cars = data;
      });
    } 
  

addCar(): void {
  this.router.navigate(['add-car']);
};

updateCar(updatecar: Car) {
  localStorage.removeItem("editcarId");
  localStorage.setItem("editcarIdd", updatecar.carId.toString());
  this.router.navigate(['edit-car']);
}
deleteCar(car: Car): void {
  let result = confirm('Do you want to delete the car?')
  if(result)
  {
    this.carService.deleteCar(car.carId)
      .subscribe( data => {
        this.cars = this.cars.filter(u => u !== car);
      });
    }
};



}





