import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Car } from 'src/app/model/car';
import { CarService } from 'src/app/_services/car.service';
import {first} from 'rxjs/operators';
@Component({
  selector: 'app-edit-car',
  templateUrl: './edit-car.component.html',
  styleUrls: ['./edit-car.component.css']
})
export class EditCarComponent implements OnInit {
    editForm: FormGroup;
  submitted: boolean = false;
  constructor(private formBuilder: FormBuilder,private router: Router, 
    private carService: CarService) {
      this.editForm = this.formBuilder.group({
        carId: [''],
        brand: ['', Validators.required],
        model: ['', Validators.required],
        variant: ['', Validators.required],
        registrationState: ['', Validators.required],
        registrationYear: ['', Validators.required]
      });
     }
  
  ngOnInit() {
    alert('onInit')
   // if(localStorage.getItem("carId")!=null){
    let carid = localStorage.getItem("editcarId");
    if(!carid) {
      alert("Invalid action.")
      this.router.navigate(['list-car']);
      alert("Invalid action56.")
      return;
    }
    

    this.carService.getCarByCarId(+carid)
      .subscribe( data => {
        this.editForm.setValue(data);
      });
   // }
  }

  onSubmit() {

    if(this.editForm.invalid){
      alert('invalid editform');
      return;
    }
    this.carService.updateCar(this.editForm.value)
      .pipe(first())
      .subscribe(
        data => {
          this.router.navigate(['list-car']);
        },
        error => {
          alert('error: '+error.url);
        });
  }

}