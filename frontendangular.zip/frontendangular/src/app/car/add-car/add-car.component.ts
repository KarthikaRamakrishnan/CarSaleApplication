import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup ,Validators} from '@angular/forms';
import {Router} from '@angular/router';
import { CarService } from 'src/app/_services/car.service';

@Component({
  selector: 'app-add-car',
  templateUrl: './add-car.component.html',
  styleUrls: ['./add-car.component.css']
})
export class AddCarComponent implements OnInit {

  addForm : FormGroup;
  submitted : boolean=false;
  constructor(private formBuilder : FormBuilder,private router : Router,private carService : CarService ) {
    this.addForm = this.formBuilder.group({
    carId:[''],
    brand: ['', Validators.required],
    model:['', Validators.required],
    variant: ['', Validators.required],
    registrationState: ['', Validators.required],
    registrationYear: ['', Validators.required]
    });
   
  }
  ngOnInit() { 

  }

  onSubmit() {
    console.log(this.addForm.value);
    this.submitted = true;
    if(this.addForm.invalid){
      alert('Invalid Data')
      return;
    }
    this.carService.createCar(this.addForm.value)
      .subscribe( data => {
        
       this.router.navigate(['list-car']);
       alert('redirecting to car-details');
      });
      this.router.navigate(['list-car']);
  }
}


