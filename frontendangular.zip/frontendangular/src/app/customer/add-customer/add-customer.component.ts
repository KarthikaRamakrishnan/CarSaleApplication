import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CustomerService } from 'src/app/_services/customer.service';

@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styleUrls: ['./add-customer.component.css']
})
export class AddCustomerComponent implements OnInit {

  addForm: FormGroup;
  submitted: boolean = false;


  constructor(private formBuilder: FormBuilder, private router: Router, 
    private customerService: CustomerService) { 
      this.addForm = this.formBuilder.group({
        id:[''],
        customerName: ['', Validators.required],
      dob:['', Validators.required],
        phoneNumber: ['', Validators.required],
        emailId: ['', Validators.required],
        address:this.formBuilder.group({
          doorNo: ['', Validators.required],
          street: ['', Validators.required],
         area: ['', Validators.required],
          city: ['', Validators.required],
          state: ['', Validators.required], 
          pincode: ['', Validators.required],
         
  
      }),
    });
    }

  ngOnInit() {
    
  }
  onSubmit() {
    this.submitted=true;
    if(this.addForm.invalid)
    {
      alert('Invalid Data');
      return;

    }
    console.log("saved");

    this.customerService.createCustomer(this.addForm.value)
      .subscribe( data => {
        this.router.navigate(['list-customer']);
      });
      this.router.navigate(['list-customer']);
    }
    
}

