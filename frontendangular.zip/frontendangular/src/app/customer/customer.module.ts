import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddCustomerComponent } from './add-customer/add-customer.component';
import { CustomerService } from 'src/app/_services/customer.service';
import { ReactiveFormsModule } from '@angular/forms';
import { ListCustomerComponent } from './list-customer/list-customer.component';
import { EditCustomerComponent } from './edit-customer/edit-customer.component';



@NgModule({
  declarations: [AddCustomerComponent,ListCustomerComponent, EditCustomerComponent ],
  imports: [
    CommonModule,
    ReactiveFormsModule
  ],
  exports:[AddCustomerComponent,ListCustomerComponent, EditCustomerComponent ],
  providers:[CustomerService]
})
export class CustomerModule { }
