import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CustomerService } from 'src/app/_services/customer.service';
import {first} from "rxjs/operators";

@Component({
  selector: 'app-edit-customer',
  templateUrl: './edit-customer.component.html',
  styleUrls: ['./edit-customer.component.css']
})
export class EditCustomerComponent implements OnInit {
  editForm: FormGroup;
  submitted: boolean = false;
  constructor(private formBuilder: FormBuilder, private router: Router, 
    private customerService: CustomerService) { 
      this.editForm = this.formBuilder.group({
        id:[''],
        customerName: ['', Validators.required],
      dob:['', Validators.required],
        phoneNumber: ['', Validators.required],
        emailId: ['', Validators.required],
        address: ['', Validators.required],
  
      });
    }

  ngOnInit() {
    let customerId=localStorage.getItem("editCustomerId");
    if(!customerId)
    {
      alert("Invalid action.")
      this.router.navigate(['list-customer']);
      return;
    }
    this.customerService.getCustomerrById(+customerId).subscribe(data=>{this.editForm.setValue(data);});
    
  }
  onSubmit() {
    if(this.editForm.invalid)
    {
      alert('Invalid editform');
      return;

    }
    this.customerService.updateCustomer(this.editForm.value)
    .pipe(first())
    . subscribe(
      data=>{
        this.router.navigate(['list-customer']);},
      error=>{
        alert('error: '+error.url);
      });
    }

}
